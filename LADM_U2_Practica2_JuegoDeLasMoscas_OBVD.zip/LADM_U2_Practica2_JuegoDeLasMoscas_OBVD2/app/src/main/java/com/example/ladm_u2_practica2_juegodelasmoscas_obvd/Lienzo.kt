package com.example.ladm_u2_practica2_juegodelasmoscas_obvd

import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.View
import java.util.*

class Lienzo (p:MainActivity) : View(p) {
    var seg = 60
    var contMoscas = 0
    var r = Random()
    var numMocas = r.nextInt(100-80)+80
    var aplastada = false
    var timerIniciado = false
    var banderaFinal = true
    var juego = true
    var xSangre = -1000f
    var ySangre = -1000f
    val timer = object : CountDownTimer(60000,1000){

        override fun onTick(millisUntilFinished: Long) {
            seg --
            redibujar()
            invalidate()
        }

        override fun onFinish() {
            banderaFinal = true
            juego = false

            if(contMoscas<=100){
                AlertDialog.Builder(p)
                    .setTitle("               G A M E O V E R")
                    .setMessage("Moscas aplastadas: ${contMoscas}")
                    .setPositiveButton("Ok"){d,i->d.dismiss()}
                    .show()
            }else{
                AlertDialog.Builder(p)
                    .setTitle("     ¡¡C O N G R A T U L A T I O N S!!")
                    .setMessage("Moscas aplastadas: ${contMoscas}")
                    .setPositiveButton("Ok"){d,i->d.dismiss()}
                    .show()
            }
        }
    }

    var mosca0 = Figuras(this, -1000f, -1000f, R.drawable.mosca)
    var mosca1 = Figuras(this, -1000f, -1000f, R.drawable.mosca)
    var mosca2 = Figuras(this, -1000f, -1000f, R.drawable.mosca)
    var mosca3 = Figuras(this, -1000f, -1000f, R.drawable.mosca)
    var mosca4 = Figuras(this, -1000f, -1000f, R.drawable.mosca)
    var sangre = Figuras(this, xSangre, ySangre, R.drawable.sangre)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val paint = Paint()
        c.drawColor(Color.BLACK)

        if (juego){
            //contador
            paint.textSize=50f
            paint.setColor(Color.WHITE)
            c.drawText("Tiempo restante: ${seg}",330f,100f,paint)

            //mosca
            mosca0.pintar(c, paint)
            mosca1.pintar(c, paint)
            mosca2.pintar(c, paint)
            mosca3.pintar(c, paint)
            mosca4.pintar(c, paint)

            //sangre
            if(aplastada){
                sangre.pintar(c, paint)
            }
        }
    }


    override fun onTouchEvent(event: MotionEvent): Boolean {
        aplastada = false
        if (juego){
            if(event.action == MotionEvent.ACTION_DOWN){
                if (timerIniciado == false){
                    timer.start()
                    timerIniciado = true
                }

                if(mosca0.estaEnArea((event.x), event.y)){
                    contMoscas = contMoscas+1
                    numMocas--
                    aplastada = true
                    sangre.manchar(Canvas(), Paint(),(event.x), event.y)
                    invalidate()
                }

                if(mosca1.estaEnArea(event.x, event.y)){
                    contMoscas = contMoscas+1
                    numMocas--
                    aplastada = true
                    sangre.manchar(Canvas(), Paint(),event.x, event.y)
                    invalidate()
                }

                if(mosca2.estaEnArea(event.x, event.y)){
                    contMoscas = contMoscas+1
                    numMocas--
                    aplastada = true
                    sangre.manchar(Canvas(), Paint(),event.x, event.y)
                    invalidate()
                }

                if(mosca3.estaEnArea(event.x, event.y)){
                    contMoscas = contMoscas+1
                    numMocas--
                    aplastada = true
                    sangre.manchar(Canvas(), Paint(),event.x, event.y)
                    invalidate()
                }

                if(mosca4.estaEnArea(event.x, event.y)){
                    contMoscas = contMoscas+1
                    numMocas--
                    aplastada = true
                    sangre.manchar(Canvas(), Paint(),event.x, event.y)
                    invalidate()
                }
            }
        }
        return true
    }

    fun redibujar(){
        mosca0.coordRandom()
        mosca1.coordRandom()
        mosca2.coordRandom()
        mosca3.coordRandom()
        mosca4.coordRandom()
    }

}
